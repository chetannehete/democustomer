/**
 * 
 */
package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;

/**
 * @author chetan
 */
@RestController
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @GetMapping("/customer")
    private List<Customer> getAllCustomer() {
        return customerService.getAllCustomer();
    }

    @GetMapping("/customer/{customerid}")
    private Customer getCustomer(@PathVariable("customerid") int customerid) {
        return customerService.getCustomerById(customerid);
    }

    @DeleteMapping("/customer/{customerid}")
    private void deleteBook(@PathVariable("customerid") int customerid) {
        customerService.delete(customerid);
    }

    @PostMapping("/customer")
    private int saveBook(@RequestBody Customer customer) {
        customerService.saveOrUpdate(customer);
        return customer.getCustomerId();
    }

    @PutMapping("/customer")
    private Customer update(@RequestBody Customer customer) {
        customerService.saveOrUpdate(customer);
        return customer;
    }

}
