/**
 * 
 */
package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Customer;

/**
 * @author chetan
 *
 */
public interface CustomerService {

    public void saveOrUpdate(Customer customer);

    public List<Customer> getAllCustomer();

    public Customer getCustomerById(int customerid);

    public void delete(int customerid);
   
}
