package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.dao.CustomerRepository;
import com.example.demo.model.Customer;

public class CustomerServiceImpl  implements CustomerService{

    @Autowired
    CustomerRepository customerRepository;

    public List<Customer> getAllCustomer() {
        List<Customer> customers = new ArrayList<Customer>();
        customerRepository.findAll().forEach(customer -> customers.add(customer));
        return customers;
    }

    public Customer getCustomerById(int id) {
        return customerRepository.findById(id).get();
    }

    public void saveOrUpdate(Customer customer) {
        customerRepository.save(customer);
    }

    public void delete(int id) {
        customerRepository.deleteById(id);
    }

    public void update(Customer customer, int bookid) {
        customerRepository.save(customer);
    }
}
